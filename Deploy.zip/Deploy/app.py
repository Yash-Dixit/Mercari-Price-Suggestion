from flask import Flask, jsonify, request
import numpy as np
import pandas as pd
import model as m
import warnings
import re
import time
import scipy
import nltk
import pickle
import math
import flask
import tensorflow as tf
import random as rn
from sklearn.externals import joblib
from tqdm import tqdm
from scipy.sparse import hstack
from tensorflow.keras.models import model_from_json, Model
from tensorflow.keras.layers import Dense, Input, Activation

warnings.filterwarnings('ignore')

app = Flask(__name__)

#Initializing global variables
number = 0
name = []
item_condition_id = []
category_name = []
brand_name = []
shipping = []
item_description = []

@app.route('/index')
def index():
    return flask.render_template('index.html')

@app.route('/index1', methods=['POST'])
def index1():
	global number 
	number = int(request.form['nm'])
	return flask.render_template('temp1/index.html')


@app.route('/predict', methods=['POST'])
def predict():
	global number
	global name
	global item_condition_id
	global category_name
	global brand_name
	global shipping
	global item_description
	to_predict_list = request.form.to_dict()
	name.append(to_predict_list['name'])
	item_condition_id.append(int(to_predict_list['item_condition_id']))
	shipping.append(int(to_predict_list['shipping']))
	if to_predict_list['category_name']=="":
		category_name.append(math.nan)
	else:
		category_name.append(to_predict_list['category_name'])
	if to_predict_list['brand_name']=="":
		brand_name.append(math.nan)
	else:
		brand_name.append(to_predict_list['brand_name'])
	if to_predict_list['item_description']=="":
		item_description.append(math.nan)
	else:
		item_description.append(to_predict_list['item_description'])
	number = number-1
	if number!=0:
		return flask.render_template('temp1/index.html')
	else:
		start_time = time.time()
		X =  pd.DataFrame({'name' : name})
		X['item_condition_id'] = item_condition_id
		X['category_name'] = category_name
		X['shipping'] = shipping
		X['brand_name'] = brand_name
		X['item_description'] = item_description
		#print(X)
		X['brand_name'] = X['brand_name'].fillna("Unknown Brand.")
		X["item_description"] = X["item_description"].fillna(value="No description yet.")
		all_text, all_text_no_punc = m.brand_text(X)
		X['brand_name'] = m.fill_brands_na(list(X['brand_name']),all_text,all_text_no_punc)
  		#del all_text_no_punc
		X['category_name'] = X['category_name'].fillna(value="Unknown Category.")
		X = m.fill_cats_na(X,all_text)
		X = m.fill_colours(X,all_text)

		item_desc_len = X["item_description"].str.len() 
		X["item_desc_len_octa"] = np.power(item_desc_len,0.125)
		del item_desc_len,all_text_no_punc
		item_name_len = X["name"].str.len()
		X["item_name_len_sqrt"] = np.sqrt(max(item_name_len+1)-item_name_len)
		del item_name_len

		# Creating a boolean column where 1 stands for [rm] is present in the description and 0 for the ones which don't have it.
		item_rm = []
		price_1 = []
		price_0 = []
		for i in range(len(list(X["item_description"]))):
			if '[rm]' in list(X["item_description"])[i]:
				item_rm.append(1)
			else:
				item_rm.append(0)
		X["Item_desc_[rm]_flag"] = item_rm

		# Creating a boolean column where 1 stands for [rm] is present in the description and 0 for the ones which don't have it.
		item_rm = []
		price_1 = []
		price_0 = []
		# Replacing NULL values with a dummy string
		for i in range(len(list(X["name"]))):
			if '[rm]' in list(X["name"])[i]:
				item_rm.append(1)
			else:
				item_rm.append(0)
		X["Name_[rm]_flag"] = item_rm
		del item_rm, price_1, price_0
		X['preprocessed_text'] = m.preprocess_text(all_text)
		del X['name'],X['item_description']
		column = list(X['item_condition_id'])

		for i in range(len(column)):
			if column[i]==1:
				column[i] = 'a'
			elif column[i]==2:
				column[i] = 'b'
			elif column[i]==3:
				column[i] = 'c'
			elif column[i]==4:
				column[i] = 'd'
			else:
				column[i] = 'e'
		X['item_condition_id'] = column
		del column

		colours = scipy.sparse.csr_matrix(X[['black', 'grey', 'white', 'beige', 
                                               'red', 'pink', 'purple', 'blue', 
                                               'green', 'yellow', 'orange', 'brown', 
                                               'gold', 'silver','Item_desc_[rm]_flag', 
                                               'Name_[rm]_flag','item_desc_len_octa',
                                               'item_name_len_sqrt','shipping']].values)
		X['number_of_colours'] = str(X['number_of_colours'])

		item_condition_id_vectorizer = pickle.load(open('item_condition_id_vectorizer.pkl', 'rb'))
		item_condition_id = item_condition_id_vectorizer.transform(X['item_condition_id'].values)
		del item_condition_id_vectorizer

		number_of_colours_vectorizer = pickle.load(open('number_of_colours_vectorizer.pkl', 'rb'))
		number_of_colours = number_of_colours_vectorizer.transform(X['number_of_colours'].values)
		del number_of_colours_vectorizer
		brand_name_codes_vectorizer = pickle.load(open('brand_name_codes_vectorizer.pkl', 'rb'))
		brand_name_codes = brand_name_codes_vectorizer.transform(X['brand_name'].values)
		del brand_name_codes_vectorizer
		main_category_codes_vectorizer = pickle.load(open('main_category_codes_vectorizer.pkl', 'rb'))
		main_category_codes = main_category_codes_vectorizer.transform(X['main_category'].values)
		del main_category_codes_vectorizer
		main_sub_category_codes_vectorizer = pickle.load(open('main_sub_category_codes_vectorizer.pkl', 'rb'))
		main_sub_category_codes = main_sub_category_codes_vectorizer.transform(X['main_sub_category'].values)
		del main_sub_category_codes_vectorizer
		sub_category_codes_vectorizer = pickle.load(open('sub_category_codes_vectorizer.pkl', 'rb'))
		sub_category_codes = sub_category_codes_vectorizer.transform(X['sub_category'].values)
		del sub_category_codes_vectorizer
		
		final_data = hstack((item_condition_id,
                       number_of_colours,
                       brand_name_codes,
                       main_category_codes,
                       main_sub_category_codes,
                       sub_category_codes,
                       colours)).tocsr()
		vectorizer_tfidf = pickle.load(open('feature_ml.pkl', 'rb'))
		X_tfidf = vectorizer_tfidf.transform(X['preprocessed_text'])
		del vectorizer_tfidf
		X_ml = hstack((final_data,X_tfidf)).tocsr().astype('float32')
		del X_tfidf
		
		filename = 'finalized_ridge.sav'
		loaded_model = pickle.load(open(filename, 'rb'))
		result_1 = np.power(loaded_model.predict(X_ml),8)
		filename = 'finalized_lgbm.sav'
		loaded_model = pickle.load(open(filename, 'rb'))
		result_2 = np.power(loaded_model.predict(X_ml),8)
		del filename, loaded_model, X_ml
		
		vectorizer_tfidf = pickle.load(open('feature_mlp.pkl', 'rb'))
		X_tfidf = vectorizer_tfidf.transform(X['preprocessed_text'])
		del vectorizer_tfidf
		X = hstack((final_data,X_tfidf)).tocsr().astype('float32')  
		del X_tfidf
		# create model
		model_in = Input(shape=(X.shape[1],), sparse=True)
		out = Dense(512, kernel_initializer='normal')(model_in)
		out = Activation('relu')(out)
		out = Dense(128, kernel_initializer='normal')(out)
		out = Activation('relu')(out)
		out = Dense(32, kernel_initializer='normal')(out)
		out = Activation('relu')(out)
		out = Dense(8, kernel_initializer='normal')(out)
		out = Activation('relu')(out)
		out = Dense(1, kernel_initializer='normal')(out)
		out = Activation('linear')(out)
		loaded_model = Model(model_in, out)
		#model_1.summary()
		# load weights into new model
		loaded_model.load_weights("mlp_model.h5")
		# evaluate loaded model on test data
		loaded_model.compile(optimizer=tf.optimizers.Adam(learning_rate=0.0005),
					loss=tf.keras.losses.MeanSquaredLogarithmicError(),
					metrics = [m.rmsle])
		result_3 = loaded_model.predict(X)
		temp = []
		for i in result_3:
			for j in i:
				temp.append(j)
		result_3 = np.array(temp)
		del X,temp
		result = 0.1*result_1 + 0.3*result_2 + 0.6*result_3
		#print(list(result_1),':',list(result_2),':',list(result_3))
		######
		return jsonify({'prediction/s': list(np.array(result)), 'time': time.time() - start_time})


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080)
