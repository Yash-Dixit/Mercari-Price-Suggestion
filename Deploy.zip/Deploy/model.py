import numpy as np
import pandas as pd
import warnings
import re
import scipy
import nltk
import pickle
import math
import tensorflow as tf
import random as rn
from nltk.stem import WordNetLemmatizer
from tqdm import tqdm
from scipy.sparse import hstack
from tensorflow.keras.models import model_from_json
nltk.download('wordnet')
lemmatizer = WordNetLemmatizer() 
warnings.filterwarnings('ignore')


def fill_brands_na(train_brand_name, all_text, all_text_no_punc):
  '''
      This function imputes the missing values for brands in the given dataset
  '''
  merge_brands_more_than_1_word, \
  brands_with_1_word, \
  brands_with_1_word_junk_extra, \
  brands_with_1_word_junk = pickle.load(open('brands.pkl', 'rb'))

  # **********IMPUTATION STARTS HERE**********
  
  for counter in range(len(train_brand_name)):
    #====================================
    # STEP 1
    #====================================

    # merge_brands_more_than_1_word --- text with punctuation
    if train_brand_name[counter] == "Unknown Brand.":
      count = 0
      for brand, preprocessed_brands in merge_brands_more_than_1_word.items():
        for preprocessed_brand in preprocessed_brands:
          if preprocessed_brand in all_text[counter]:
            train_brand_name[counter] = brand
            count = 1
            break
        if count>0:
          break
        
    if train_brand_name[counter] != "Unknown Brand.":
      continue

    # merge_brands_more_than_1_word --- text with no punctuation
    if train_brand_name[counter] == "Unknown Brand.":
      count = 0
      for brand, preprocessed_brands in merge_brands_more_than_1_word.items():
        for preprocessed_brand in preprocessed_brands:
          if preprocessed_brand in all_text_no_punc[counter]:
            train_brand_name[counter] = brand
            count = 1
            break
        if count>0:
          break

    if train_brand_name[counter] != "Unknown Brand.":
      continue

    #====================================
    # STEP 2
    #====================================

    # brands_with_1_word --- text with punctuation
    if train_brand_name[counter] == "Unknown Brand.":
      count = 0
      for brand, preprocessed_brands in brands_with_1_word.items():
        for preprocessed_brand in preprocessed_brands:
          if preprocessed_brand in all_text[counter].split():
            train_brand_name[counter] = brand
            count = 1
            break
        if count>0:
          break

    if train_brand_name[counter] != "Unknown Brand.":
      continue

    #brands_with_1_word --- text with no punctuation
    if train_brand_name[counter] == "Unknown Brand.":
      count = 0
      for brand, preprocessed_brands in brands_with_1_word.items():
        for preprocessed_brand in preprocessed_brands:
          if preprocessed_brand in all_text_no_punc[counter].split():
            train_brand_name[counter] = brand
            count = 1
            break
        if count>0:
          break

    if train_brand_name[counter] != "Unknown Brand.":
      continue

    #====================================
    # STEP 3
    #====================================

    #brands_with_1_word_junk_extra --- text with punctuation
    if train_brand_name[counter] == "Unknown Brand.":
      count = 0
      for brand, preprocessed_brands in brands_with_1_word_junk_extra.items():
        for preprocessed_brand in preprocessed_brands:
          if preprocessed_brand in all_text[counter]:
            train_brand_name[counter] = brand
            count = 1
            break
        if count>0:
          break
        
    if train_brand_name[counter] != "Unknown Brand.":
      continue

    # brands_with_1_word_junk_extra --- text with no punctuation
    if train_brand_name[counter] == "Unknown Brand.":
      count = 0
      for brand, preprocessed_brands in brands_with_1_word_junk_extra.items():
        for preprocessed_brand in preprocessed_brands:
          if preprocessed_brand in all_text_no_punc[counter]:
            train_brand_name[counter] = brand
            count = 1
            break
        if count>0:
          break

    if train_brand_name[counter] != "Unknown Brand.":
      continue

    #====================================
    # STEP 4
    #====================================

    # brands_with_1_word_junk --- text with punctuation
    if train_brand_name[counter] == "Unknown Brand.":
      count = 0
      for brand, preprocessed_brands in brands_with_1_word_junk.items():
        for preprocessed_brand in preprocessed_brands:
          if preprocessed_brand in all_text[counter].split():
            train_brand_name[counter] = brand
            count = 1
            break
        if count>0:
          break

    if train_brand_name[counter] != "Unknown Brand.":
      continue

    #brands_with_1_word_junk --- text with no punctuation
    if train_brand_name[counter] == "Unknown Brand.":
      count = 0
      for brand, preprocessed_brands in brands_with_1_word_junk.items():
        for preprocessed_brand in preprocessed_brands:
          if preprocessed_brand in all_text_no_punc[counter].split():
            train_brand_name[counter] = brand
            count = 1
            break
        if count>0:
          break

  del merge_brands_more_than_1_word
  del brands_with_1_word
  del brands_with_1_word_junk_extra
  del brands_with_1_word_junk

  return train_brand_name


def brand_text(df):
  '''
  This function preprocesses the textual data present in the dataset
  '''
  
  df["item_description"] = df["item_description"].fillna(value="No description yet.")
  all_text = list(df['name']+" "+df['item_description'])

  #define punctuation
  all_text_no_punc = []
  punctuations = '!()-[]{};:\'\"\,<>./?@#$%^&*_~©®™'
  for i in range(len(all_text)):
    no_punct = ""
    for char in all_text[i]:
      if char not in punctuations:
        no_punct = no_punct + char
      else:
        no_punct = no_punct + " "
    #Appending the text version with no punctuations
    all_text_no_punc.append((" ".join(no_punct.split())).lower())
    #Appending the text version with punctuations
    all_text[i] = all_text[i].lower()

  return all_text, all_text_no_punc


def fill_cats(cat_list, cat_string, unique_categories, all_text):
  for i in range(len(cat_list)):
    if cat_list[i] == cat_string:
      count = 0
      for k,v in unique_categories.items():
        for cat in v:
          if cat in all_text[i]:
            cat_list[i] = k
            count = 1
            break
        if count>0:
          break
  return cat_list

def fill_cats_na(X,all_text):
  main_categories = pickle.load(open('main_cats.pkl', 'rb'))
  main_sub_categories = pickle.load(open('main_sub_cats.pkl', 'rb'))
  sub_categories = pickle.load(open('sub_cats.pkl', 'rb'))

  # There are 3 categories per Category Name in the data.
  # The format of the category is : main_category/main_sub_category/sub_category
  # So I have created 3 lists to split them with respect to the punctuation '/'.
  # This is the code to create lists of main and its sub-categories

  categories = list(X['category_name'])
  main_category = []
  main_sub_category = []
  sub_category = []

  for i in categories:
    if not i=="Unknown Category.":
      temp = i.split('/')
      main_category.append(temp[0])
      main_sub_category.append(temp[1])
      sub_category.append(temp[2])
    else:
      main_category.append("Unknown Main-Category.")
      main_sub_category.append("Unknown Main-Sub-Category.")
      sub_category.append("Unknown Sub-Category.")

  main_category = fill_cats(main_category,"Unknown Main-Category.",main_categories,all_text)
  del main_categories
  main_sub_category = fill_cats(main_sub_category,"Unknown Main-Sub-Category.",main_sub_categories,all_text)
  del main_sub_categories
  sub_category = fill_cats(sub_category,"Unknown Sub-Category.",sub_categories,all_text)
  del sub_categories

  X['main_category'] = main_category
  del main_category
  X['main_sub_category'] = main_sub_category
  del main_sub_category
  X['sub_category'] = sub_category
  del sub_category
  del X['category_name']
  return X

def fill_colours(X,all_text):
  colours = ["black",
           "grey",
           "white",
           "beige",
           "red",
           "pink",
           "purple",
           "blue",
           "green",
           "yellow",
           "orange",
           "brown",
           "gold",
           "silver"]

  # Initializing a list containing the number of colours present in the text
  number_of_colours = []

  # Initializing a dictionary where - 
  # keys : The colours
  # values : lists containing whether the colour is present or not
  colours_dictionary = {}

  number_of_colours = list(np.zeros(len(X["name"]),np.int))

  for colour in colours:
    temp = []
    counter = 0
    for a in all_text:
      if colour in a:
        temp.append(1)
        number_of_colours[counter] = number_of_colours[counter] + 1
      else:
        temp.append(0)
      counter = counter +1
    colours_dictionary[colour] = temp

  for k,v in colours_dictionary.items():
    X[k] = v
  X["number_of_colours"] = number_of_colours
  return X

def preprocess_text(all_text):
  '''
  This function preprocesses the item description and name of the datasets
  '''

  for i in range(len(all_text)):
    #Preprocessing the words with apostrophes and new line characters as well
    all_text[i] = re.sub(r"won't", "will not", all_text[i])
    all_text[i] = re.sub(r"can\'t", "can not", all_text[i])
    all_text[i] = re.sub(r"n\'t", " not", all_text[i])
    all_text[i] = re.sub(r"\'re", " are", all_text[i])
    all_text[i] = re.sub(r"\'s", " is", all_text[i])
    all_text[i] = re.sub(r"\'d", " would", all_text[i])
    all_text[i] = re.sub(r"\'ll", " will", all_text[i])
    all_text[i] = re.sub(r"\'t", " not", all_text[i])
    all_text[i] = re.sub(r"\'ve", " have", all_text[i])
    all_text[i] = re.sub(r"\'m", " am", all_text[i])
    all_text[i] = all_text[i].replace('\\r', ' ')
    all_text[i] = all_text[i].replace('\\n', ' ')
    all_text[i] = all_text[i].replace('\\"', ' ')
    #Getting rid of unnecessary spaces
    #all_text[i] = ' '.join(e.lower() for e in all_text[i].split() if e.lower() not in stopwords)
    #Keeping only the alphanumeric characters and discarding the rest
    all_text[i] = re.sub('[^A-Za-z0-9 ]', ' ', all_text[i])
    #Getting rid of unnecessary spaces
    #all_text[i] = ' '.join(e.lower() for e in all_text[i].split() if e.lower() not in stopwords)
    all_text[i] = ' '.join(e.lower() for e in all_text[i].split())
    # Converting "24ml" to "24 ml" or even "2v2" to '2 v 2' or many combinations as well
    all_text[i] = re.sub('(?<=[A-Za-z])(?=[0-9])|(?<=[0-9])(?=[A-Za-z])',' ', all_text[i])
    
    #The code below lemmatizes the text wherein inherited texts of a word in substituted with the parent word.
    #For example, go, gone, went and goes will be substituted with the parent word go.
    # I have lemmatized both nouns as well as verbs for that matter
    
    # n denotes "NOUN" in "pos"
    all_text[i] = ' '.join(lemmatizer.lemmatize(i, pos ="n") for i in all_text[i].split())
    # v denotes "VERB" in "pos"
    all_text[i] = ' '.join(lemmatizer.lemmatize(i, pos ="v") for i in all_text[i].split())
  
  return all_text

def rmsle_score_1(actual, predicted, shape):
  if shape>1:
    return np.sqrt(np.nansum(np.square(np.log(predicted+1) - np.log(actual+1)))/float(len(actual)))
  else:
    return np.sqrt(np.nansum(np.square(np.log(predicted+1) - np.log(actual+1)))/float(1.0))


def rmsle_score(actual, predicted, shape):
  return np.sqrt(np.nansum(np.square(np.log(predicted+1) - np.log(actual+1)))/float(len(actual)))

def rmsle(y_true, y_pred):
    return tf.py_function(rmsle_score, (y_true, y_pred), tf.double)
